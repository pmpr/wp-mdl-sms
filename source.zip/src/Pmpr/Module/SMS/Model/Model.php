<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6998d80e39a30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Model; use Pmpr\Common\Foundation\ORM\Model as BaseClass; abstract class Model extends BaseClass { }
