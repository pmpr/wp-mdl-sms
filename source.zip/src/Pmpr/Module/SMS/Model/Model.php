<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69998e2d4fe60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Model; use Pmpr\Common\Foundation\ORM\Model as BaseClass; abstract class Model extends BaseClass { }
