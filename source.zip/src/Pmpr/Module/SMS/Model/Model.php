<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999928d4e8dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Model; use Pmpr\Common\Foundation\ORM\Model as BaseClass; abstract class Model extends BaseClass { }
