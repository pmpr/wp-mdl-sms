<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999928d4e8dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\SMS\Provider\Kavenegar\Setting as KavenegarSetting; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->gswweykyogmsyawy(__('SMS', PR__MDL__SMS))->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __('SMS Setting', PR__MDL__SMS)); parent::qiccuiwooiquycsg(); } public function ykwqaukkycogooii() { parent::ykwqaukkycogooii(); $this->kwugkiaumqigagwm(); } public function kwugkiaumqigagwm() { KavenegarSetting::symcgieuakksimmu(); } }
