<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69998e2d4fe60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\SMS\Provider\Kavenegar\Setting as KavenegarSetting; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->gswweykyogmsyawy(__('SMS Panel', PR__MDL__SMS))->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __('SMS Panel Setting', PR__MDL__SMS)); parent::qiccuiwooiquycsg(); } public function ykwqaukkycogooii() { parent::ykwqaukkycogooii(); $this->kwugkiaumqigagwm(); } public function kwugkiaumqigagwm() { KavenegarSetting::symcgieuakksimmu(); } }
