<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999aa94069c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; abstract class SettingSegment extends Segment { public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
