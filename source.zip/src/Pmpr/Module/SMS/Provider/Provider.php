<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999aa94069c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Provider; use Pmpr\Common\Foundation\API\WPRemote; abstract class Provider extends WPRemote { }
