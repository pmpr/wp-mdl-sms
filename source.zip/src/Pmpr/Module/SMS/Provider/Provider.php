<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999928d4e8dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Provider; use Pmpr\Common\Foundation\API\WPRemote; abstract class Provider extends WPRemote { }
