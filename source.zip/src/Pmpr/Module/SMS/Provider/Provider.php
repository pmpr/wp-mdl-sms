<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a09c816d68e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Provider; use Pmpr\Common\Foundation\API\WPRemote; abstract class Provider extends WPRemote { }
