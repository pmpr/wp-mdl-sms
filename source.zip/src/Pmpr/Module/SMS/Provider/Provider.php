<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6998d80e39a30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Provider; use Pmpr\Common\Foundation\API\WPRemote; abstract class Provider extends WPRemote { }
