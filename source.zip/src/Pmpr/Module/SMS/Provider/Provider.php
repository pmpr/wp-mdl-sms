<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69998e2d4fe60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS\Provider; use Pmpr\Common\Foundation\API\WPRemote; abstract class Provider extends WPRemote { }
