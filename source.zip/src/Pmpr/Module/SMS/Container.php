<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69998e2d4fe60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
