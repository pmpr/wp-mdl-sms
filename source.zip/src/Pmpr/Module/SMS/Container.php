<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6998d80e39a30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
