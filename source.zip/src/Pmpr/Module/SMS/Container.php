<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999aa94069c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SMS; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
