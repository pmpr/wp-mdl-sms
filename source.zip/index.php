<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a09c816d68e             |
    |_______________________________________|
*/
 use Pmpr\Module\SMS\Engine; use Pmpr\Module\SMS\SMS; SMS::symcgieuakksimmu(); if (!function_exists('pr_sms_get_engine')) { function pr_sms_get_engine() { return Engine::symcgieuakksimmu(); } }
